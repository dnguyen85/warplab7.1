IN_BANK0 = hex2dec('0');
IN_BANK1 = hex2dec('20202020');

OUT0 = hex2dec('80000100');
OUT1 = hex2dec('80000900');
OUT2 = hex2dec('0');
OUT3 = hex2dec('0');
OUT4 = hex2dec('0');
OUT5 = hex2dec('0');
