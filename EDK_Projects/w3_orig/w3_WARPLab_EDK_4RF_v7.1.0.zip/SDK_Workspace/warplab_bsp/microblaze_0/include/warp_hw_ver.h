#ifndef _WARP_HW_VER_H
#define _WARP_HW_VER_H

#define WARP_HW_VER_v3 1
#define WARP_HW_VER_v3_REV1p0 1

#endif
