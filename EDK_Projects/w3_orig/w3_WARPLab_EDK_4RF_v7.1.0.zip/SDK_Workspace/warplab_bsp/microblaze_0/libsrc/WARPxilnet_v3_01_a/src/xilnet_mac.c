////////////////////////////////////////////////////////////////////////////////
// Copyright (c) 2004 Xilinx, Inc.  All rights reserved. 
// 
// Xilinx, Inc. 
// XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A 
// COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS 
// ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR 
// STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION 
// IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE 
// FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION. 
// XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO 
// THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO 
// ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE 
// FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY 
// AND FITNESS FOR A PARTICULAR PURPOSE. 
// 
// File   : mac.c
// Date   : 2002, March 20.
// Author : Sathya Thammanur
// Company: Xilinx
// Group  : Emerging Software Technologies
//
// Summary:
// MAC layer specific functions
//
// $Id: mac.c,v 1.2.8.6 2005/11/15 23:41:10 salindac Exp $
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
// see copyright.txt for Rice University/Mango Communications modifications
////////////////////////////////////////////////////////////////////////////////

#include "xilnet_config.h"

#ifdef _CONFIG_EMACLITE_
extern unsigned int MYMAC_BASEADDR;
void xilnet_mac_init(unsigned int baseaddr) {
   MYMAC_BASEADDR = baseaddr;
}
#endif

#ifdef _CONFIG_TEMAC_
extern void* FIFO_INST;
extern void* DMA_CENTRAL_INST;

void xilnet_mac_init(void* fifoInst, void* dmaInst) {
   FIFO_INST = fifoInst;
   DMA_CENTRAL_INST = dmaInst;
}

#endif
#ifdef _CONFIG_AXI_ETHERNET_FIFO
extern void* FIFO_INST;

void xilnet_mac_init(void* fifoInst, void* dmaInst) {
   FIFO_INST = fifoInst;
}

#endif


